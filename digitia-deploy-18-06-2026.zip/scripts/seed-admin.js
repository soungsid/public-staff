/**
 * seed-admin.js — Crée le compte administrateur initial
 *
 * Utilise uniquement pg + bcrypt (présents dans l'image serveur).
 * Aucune dépendance sur ts-node ou le code source TypeScript.
 *
 * Usage:
 *   docker compose exec server node /seed/seed-admin.js
 *
 * Variables d'environnement requises:
 *   DATABASE_URL, ADMIN_LOGIN, ADMIN_PASSWORD
 */
const { Client } = require("pg");
const bcrypt = require("bcrypt");
const crypto = require("crypto");

async function main() {
  const login = process.env.ADMIN_LOGIN;
  const password = process.env.ADMIN_PASSWORD;

  if (!login || !password) {
    console.error("❌ ADMIN_LOGIN et ADMIN_PASSWORD doivent être définis dans .env");
    process.exit(1);
  }

  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  try {
    const { rows } = await client.query(
      'SELECT id FROM "User" WHERE login = $1',
      [login]
    );

    const hash = await bcrypt.hash(password, 10);

    if (rows.length > 0) {
      // User exists, update password
      const userId = rows[0].id;
      await client.query(
        'UPDATE "User" SET password = $1 WHERE id = $2',
        [hash, userId]
      );
      console.log(`✅ Mot de passe de l'admin '${login}' mis à jour avec succès.`);
      return;
    }

    // User doesn't exist, insert new admin
    await client.query(
      `INSERT INTO "User" (id, login, name, role, password, firstname, lastname, organization)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [crypto.randomUUID(), login, "System Admin", "admin", hash, "Admin", "Digitia", "System"]
    );

    console.log(`✅ Admin '${login}' créé avec succès.`);
  } finally {
    await client.end();
  }
}

main().catch((e) => {
  console.error("❌ Erreur:", e.message);
  process.exit(1);
});
