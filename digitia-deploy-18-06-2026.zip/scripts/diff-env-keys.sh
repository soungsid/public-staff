#!/usr/bin/env bash
# Compare uniquement les noms de variables entre deux fichiers .env — jamais les valeurs.
# Usage : ./scripts/diff-env-keys.sh secrets/.env.umef secrets/.env.demo
set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <file1> <file2>" >&2
  exit 1
fi

FILE1="$1"
FILE2="$2"

if [ ! -f "$FILE1" ]; then
  echo "Fichier introuvable : $FILE1" >&2
  exit 1
fi

if [ ! -f "$FILE2" ]; then
  echo "Fichier introuvable : $FILE2" >&2
  exit 1
fi

keys1=$(grep -E '^[A-Za-z_][A-Za-z0-9_]*=' "$FILE1" | cut -d= -f1 | sort -u)
keys2=$(grep -E '^[A-Za-z_][A-Za-z0-9_]*=' "$FILE2" | cut -d= -f1 | sort -u)

echo "=== Variables présentes dans $FILE1 uniquement ==="
comm -23 <(echo "$keys1") <(echo "$keys2") || true

echo ""
echo "=== Variables présentes dans $FILE2 uniquement ==="
comm -13 <(echo "$keys1") <(echo "$keys2") || true
