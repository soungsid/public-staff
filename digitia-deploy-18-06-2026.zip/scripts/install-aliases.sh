#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# install-aliases.sh — installe les alias/fonctions Digitia pour TOUS les
# utilisateurs du serveur, de façon reproductible et idempotente.
#
# Pose les définitions dans /etc/profile.d/digitia-aliases.sh : ce répertoire est
# sourcé automatiquement par tout shell de login (dont les sessions SSH). Aucune
# édition manuelle d'un ~/.bashrc par utilisateur n'est nécessaire.
#
# Usage (sur le serveur, depuis le dépôt digitia-deploy) :
#   ./scripts/install-aliases.sh
#   WORKDIR=/chemin/perso ./scripts/install-aliases.sh   # surcharge le WORKDIR par défaut
#
# Réexécuter après chaque mise à jour de digitia-aliases.sh met les alias à jour.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_DIR/digitia-aliases.sh"
DEST="/etc/profile.d/digitia-aliases.sh"

[ -f "$SRC" ] || { echo "❌ Introuvable : $SRC" >&2; exit 1; }

# sudo seulement si on n'est pas déjà root.
SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

# Permet de figer le WORKDIR du serveur dans le fichier installé (sinon la valeur
# par défaut du fichier de définitions s'applique au login).
if [ -n "${WORKDIR:-}" ]; then
  $SUDO install -m 0644 /dev/stdin "$DEST" <<EOF
# Généré par install-aliases.sh — ne pas éditer à la main.
export WORKDIR="$WORKDIR"
source "$SRC"
EOF
else
  $SUDO install -m 0644 "$SRC" "$DEST"
fi

echo "✅ Alias Digitia installés : $DEST"
echo "   Effectif à la prochaine session de login. Pour la session courante :"
echo "   source $DEST"
