/**
 * seed-templates.js — Crée les modèles de document par défaut
 *
 * Utilise uniquement pg (présent dans l'image serveur).
 * Idempotent : vérifie l'existence par titre avant insertion (évite d'écraser les modifs admin).
 *
 * Usage:
 *   docker compose exec -e NODE_PATH=/app/node_modules server node /seed/seed-templates.js
 *
 * Variables d'environnement requises: DATABASE_URL
 */
const { Client } = require("pg");

const SEED_TEMPLATES = [
  {
    title: 'Rapport provisoire',
    category: 'inspection',
    status: 'active',
    description: "Modèle de rapport d'inspection provisoire",
    content: '# Rapport provisoire\n\n## En-tête\n\n## Constats\n\n## Conclusions provisoires',
    tags: ['rapport', 'provisoire']
  },
  {
    title: "Note d'analyse réponse banque",
    category: 'banque',
    status: 'active',
    description: "Note d'analyse pour réponse bancaire",
    content: "# Note d'analyse\n\n## Objet\n\n## Analyse\n\n## Recommandation",
    tags: ['banque', 'analyse']
  },
  {
    title: 'Synthèse executive',
    category: 'synthese',
    status: 'active',
    description: 'Synthèse destinée à la direction',
    content: '# Synthèse executive\n\n## Points clés\n\n## Recommandations',
    tags: ['synthese', 'executive']
  },
  {
    title: "Lettre d'observation",
    category: 'inspection',
    status: 'active',
    description: "Lettre d'observation formelle",
    content: "# Lettre d'observation\n\n## Objet\n\n## Observations\n\n## Suites données",
    tags: ['lettre', 'observation']
  },
  {
    title: 'Rapport définitif',
    category: 'inspection',
    status: 'active',
    description: "Rapport d'inspection final et définitif",
    content: '# Rapport définitif\n\n## En-tête\n\n## Constats définitifs\n\n## Conclusion',
    tags: ['rapport', 'definitif']
  },
  {
    title: 'Fiche dossier',
    category: 'synthese',
    status: 'active',
    description: 'Fiche résumé du dossier (1 page)',
    content: '# Fiche dossier\n\n## Informations générales\n\n## Points essentiels\n\n## Statut',
    tags: ['fiche', 'dossier']
  }
];

async function main() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  try {
    let insertedCount = 0;

    for (const template of SEED_TEMPLATES) {
      const { rows } = await client.query(
        'SELECT id FROM "document_template" WHERE title = $1',
        [template.title]
      );

      if (rows.length > 0) {
        console.log(`📄 Template "${template.title}" already exists. Skipping to avoid overwriting changes.`);
      } else {
        console.log(`➕ Creating template "${template.title}"...`);
        await client.query(
          `INSERT INTO "document_template" (title, category, status, description, content, tags, created_at, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())`,
          [
            template.title,
            template.category,
            template.status,
            template.description,
            template.content,
            template.tags
          ]
        );
        insertedCount++;
      }
    }

    console.log(`✅ Seeding complete. Created: ${insertedCount} templates.`);
  } finally {
    await client.end();
  }
}

main().catch((e) => {
  console.error("❌ Erreur:", e.message);
  process.exit(1);
});
