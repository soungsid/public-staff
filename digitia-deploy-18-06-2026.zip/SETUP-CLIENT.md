# 🚀 Guide de déploiement Digitia — Client

## Prérequis

- Docker et Docker Compose installés
- Un compte GitHub avec accès au projet (fourni par Digitia)
- Un **token d'accès** Docker (fourni par Digitia)

---

## 1. Cloner le dépôt de déploiement

```bash
git clone https://github.com/digitia-org/digitia-deploy.git
cd digitia-deploy
```

## 2. Se connecter au registre d'images Docker (GHCR)

Un token vous sera fourni par l'équipe Digitia. Exécutez :

```bash
echo "TOKEN_FOURNI" | docker login ghcr.io -u digitia-deploy-bot --password-stdin
```

Vous devriez voir `Login Succeeded`.

## 3. Configurer l'environnement

```bash
cp .env.example .env
```

Ouvrez `.env` et remplissez **toutes les valeurs marquées `CHANGER_MOI`** :

| Variable | Description | Exemple |
|----------|-------------|---------|
| `POSTGRES_PASSWORD` | Mot de passe PostgreSQL (min 16 car.) | `monMotDePasse1234!` |
| `ADMIN_LOGIN` | Email du compte administrateur | `admin@monentreprise.com` |
| `ADMIN_PASSWORD` | Mot de passe admin (premier démarrage) | `Admin2026!secure` |
| `NEO4J_PASSWORD` | Mot de passe Neo4j (min 8 car.) | `neo4jPassword123` |
| `GEMINI_API_KEY` | Clé API Google Gemini | `AIzaSy...` |

> ⚠️ **Important** : Mettez aussi à jour le fichier `pgadmin-config/pgpass` avec le même mot de passe PostgreSQL que dans `.env` :
> ```
> postgres:5432:explor:postgres:VOTRE_MOT_DE_PASSE_POSTGRES
> ```

> Mettez aussi `OTEL_ENABLED=false` dans `.env` (l'observabilité est réservée
> aux serveurs gérés par Digitia).

## 4. Démarrer les services

L'installation client se fait **sans Traefik**, via l'override local. Ne lancez
pas la base seule : il est nécessaire de superposer l'override local (`docker-compose.local.yml`) pour que les ports applicatifs (ex: 3000 pour le frontend) soient exposés sur votre machine.

```bash
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml pull
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml up -d
```

Le premier démarrage prend quelques minutes (téléchargement des images, migrations
et seeds automatiques).

> 💡 Astuce : `export COMPOSE_FILE=docker-compose.yml:docker-compose.infra.yml:docker-compose.local.yml`
> permet ensuite d'utiliser simplement `docker compose <cmd>`.

## 5. Vérifier que tout fonctionne

```bash
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml ps
```

Tous les services doivent être `Up` ou `Healthy` :

| Service | URL | Description |
|---------|-----|-------------|
| Frontend | http://localhost:3000 | Application Digitia |
| API Server | http://localhost:3001/api/health | API (doit répondre `ok`) |
| pgAdmin | http://localhost:5050 | Administration PostgreSQL |
| Neo4j | http://localhost:7474 | Base graphe |

Connexion à l'application : `ADMIN_LOGIN` / `ADMIN_PASSWORD` définis dans `.env`.

## 6. Commandes utiles

```bash
# Voir les logs d'un service
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml logs digitia-server --tail 50

# Redémarrer un service
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml restart digitia-server

# Arrêter tout (conserve les données)
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml down

# Mettre à jour les images
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml pull
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml up -d
```

---

## Dépannage

### `unauthorized` ou `403` au pull des images
→ Vérifiez que `docker login ghcr.io` a été fait avec le bon token.

### Le serveur redémarre en boucle
→ Vérifiez que PostgreSQL est healthy : `docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml logs digitia-postgres`
→ Vérifiez `DATABASE_URL` dans les logs : `docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml logs digitia-server`

### `network traefik_network declared as external, but could not be found`
→ Vous avez inclus le fichier override Traefik (`docker-compose.label-traefik.yml`) sans que la stack Traefik principale (qui crée ce réseau externe) ne tourne sur votre hôte. Assurez-vous d'utiliser l'override local (`docker-compose.local.yml`) si vous déployez en local.

---

## Support

Contactez l'équipe Digitia pour :
- Renouvellement du token d'accès Docker
- Mise à jour vers une nouvelle version
- Problèmes techniques

---

## Suivi des déploiements clients

À appliquer **à chaque déploiement** :

1. Mettre à jour `DIGITIA_VERSION` dans `secrets/.env.<client>` = tag d'image déployé
2. Ajouter une ligne dans [`DEPLOYMENTS.md`](./DEPLOYMENTS.md) (colonnes : Date, Heure, Client/Env, Config, Version, Opérateur, Health check, Notes)
3. Mettre à jour la fiche client `clients/<client>.md` (version + date du dernier déploiement)

Pour diagnostiquer :
- **Version qui tourne** = `DIGITIA_VERSION` dans `secrets/.env.<client>`
- **Comparer deux configs** (sans fuite de secret) : `./scripts/diff-env-keys.sh secrets/.env.<client1> secrets/.env.<client2>`

Fiches clients disponibles : [`clients/`](./clients/)
