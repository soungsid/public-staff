# Digitia Deploy

Configurations de déploiement Docker Compose pour la plateforme **Digitia**.
Les images Docker sont publiées sur GHCR : `ghcr.io/digitia-org/`.

## Sommaire

- [1. Vue d'ensemble](#1-vue-densemble)
  - [1.1 Architecture des services](#11-architecture-des-services)
  - [1.2 Structure du dépôt](#12-structure-du-dépôt)
  - [1.3 Modèle de composition (compose files)](#13-modèle-de-composition-compose-files)
- [2. Prérequis](#2-prérequis)
- [3. Authentification au registre GHCR](#3-authentification-au-registre-ghcr)
- [4. Configuration (`.env`)](#4-configuration-env)
- [5. Déploiement local (sans Traefik)](#5-déploiement-local-sans-traefik)
- [6. Déploiement serveur (avec Traefik + HTTPS)](#6-déploiement-serveur-avec-traefik--https)
- [7. Vérification et accès](#7-vérification-et-accès)
- [8. Exploitation au quotidien](#8-exploitation-au-quotidien)
- [9. Dépannage](#9-dépannage)
- [10. Bonnes pratiques](#10-bonnes-pratiques)
- [11. Support](#11-support)

---

## 1. Vue d'ensemble

### 1.1 Architecture des services

Digitia est une plateforme RAG multi-agent composée des services suivants (tous
orchestrés par Docker Compose) :

| Service | Rôle | Image | Port (local) |
|---|---|---|---|
| `digitia-app` | Frontend React (Nginx) | `ghcr.io/digitia-org/digitia-frontend` | `3000` |
| `digitia-server` | API Gateway (Node.js / Express) | `ghcr.io/digitia-org/digitia-server` | `3001` |
| `digitia-agent-backend` | Agent IA (FastAPI / LangGraph) | `ghcr.io/digitia-org/digitia-agent` | `8000` |
| `digitia-postgres` | Base relationnelle + pgvector | `pgvector/pgvector:pg16` | interne |
| `digitia-neo4j` | Base graphe | `neo4j:2026.01.4` | `7474` / `7687` |
| `digitia-minio` | Stockage objet S3 | `minio/minio` | `9000` / `9001` |
| `digitia-pgadmin` | Administration PostgreSQL | `dpage/pgadmin4` | `5050` |
| `digitia-obs-collector` | OTel Collector (observabilité) | `otel/opentelemetry-collector-contrib` | — |
| `digitia-obs-alloy` | Collecte des logs Docker | `grafana/alloy` | — |

> Les deux services d'observabilité (`obs-*`) sont sous le **profil Compose
> `observability`** : ils ne démarrent **pas** par défaut. Ils sont activés
> uniquement sur les serveurs gérés (dev/demo/prod). En local, l'observabilité
> est désactivée.

### 1.2 Structure du dépôt

```
digitia-deploy/
├── docker-compose.yml                # Apps (le code) : server, agent, frontend
├── docker-compose.infra.yml          # Infra : postgres, neo4j, minio, pgadmin, observabilité
├── docker-compose.local.yml          # Override LOCAL — sans Traefik, sans observabilité
├── docker-compose.label-traefik.yml  # Override SERVEUR — labels Traefik + réseau traefik_network
├── .env.example                      # Template de configuration → copier en .env
├── init-db.sql                       # Initialisation PostgreSQL (extension pgvector)
├── deploy-manifest.yml               # Source de vérité du déploiement (CI/CD)
├── runbook-digitia.md                # Procédures d'exploitation (secrets, reset, diagnostic)
├── SETUP-CLIENT.md                   # Guide d'installation client (on-prem)
├── pgadmin-config/
│   ├── servers.json                  # Connexion pgAdmin → PostgreSQL
│   └── pgpass/                       # Credentials pgAdmin
├── observability/                    # Configs OTel Collector + Alloy
└── scripts/                          # Seeds (admin, agents, templates), reset SQL
```

> ℹ️ **Traefik n'est pas dans ce dépôt.** Sur les serveurs, Traefik tourne dans
> un projet Docker Compose **séparé** (`-p traefik`) qui crée le réseau externe
> `traefik_network`. En local, ce réseau n'est pas nécessaire et n'est pas utilisé (voir §5).

### 1.3 Modèle de composition (compose files)

Le compose est **scindé** : `docker-compose.yml` (apps) et `docker-compose.infra.yml` (infra). Cette séparation permet d'exécuter, d'arrêter et de redémarrer les applications de manière 100 % indépendante des bases de données et des services de stockage (qui mettent du temps à s'initialiser).

| Cible / Usage | Commande de base |
|---|---|
| **Tout démarrer en Local** | `docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml up -d` |
| **Démarrer l'infra seule** | `docker compose -f docker-compose.infra.yml up -d` |
| **Démarrer les apps seules (local)** | `docker compose -f docker-compose.yml -f docker-compose.local.yml up -d` |
| **Tout démarrer sur Serveur (Traefik)** | `docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.label-traefik.yml up -d` |

> 💡 **Autonomie & Résilience (Auto-healing)** : Les fichiers d'applications n'ont aucune dépendance de validation rigide (`depends_on` vers l'infrastructure). Si vous démarrez les applications alors que la base de données PostgreSQL n'est pas encore prête, les conteneurs d'applications vont échouer à la connexion et s'arrêter. Grâce à la règle `restart: unless-stopped`, Docker les redémarrera automatiquement à intervalles réguliers. Dès que la base de données sera disponible, ils se connecteront et resteront en ligne, sans intervention manuelle.

---

## 2. Prérequis

- **Docker Engine ≥ 24**
- **Docker Compose ≥ 2** (plugin `docker compose`, pas `docker-compose` v1)
- Accès **lecture** au registre GHCR (token fourni par Digitia — voir §3)
- ~6 Go de RAM disponibles (Neo4j + Postgres + agent)

Vérifier l'installation :

```bash
docker --version
docker compose version
```

---

## 3. Authentification au registre GHCR

Les images sont privées. Se connecter avec l'utilisateur et le token fournis par
Digitia (scope `read:packages`, lecture seule) :

```bash
echo "VOTRE_TOKEN" | docker login ghcr.io -u UTILISATEUR_FOURNI --password-stdin
```

Vous devez voir `Login Succeeded`.

---

## 4. Configuration (`.env`)

Copier le template puis renseigner **toutes les valeurs `CHANGER_MOI`** :

```bash
cp .env.example .env
```

Variables **obligatoires** :

| Variable | Description | Exemple |
|---|---|---|
| `POSTGRES_PASSWORD` | Mot de passe PostgreSQL (≥ 16 car.) | `Pg_S3cret_2026!xy` |
| `ADMIN_LOGIN` | Email du compte admin Digitia | `admin@monentreprise.com` |
| `ADMIN_PASSWORD` | Mot de passe admin (créé au 1er démarrage) | `Admin2026!secure` |
| `NEO4J_PASSWORD` | Mot de passe Neo4j (≥ 8 car.) | `Neo4j_Pass_123` |
| `GEMINI_API_KEY` | Clé API Google Gemini ([AI Studio](https://aistudio.google.com/apikey)) | `AIzaSy...` |
| `GOOGLE_API_KEY` | Même valeur que `GEMINI_API_KEY` | `AIzaSy...` |

Variables utiles :

| Variable | Rôle | Valeur locale recommandée |
|---|---|---|
| `DIGITIA_VERSION` | Tag des images à déployer | `develop` (ou une version, ex. `1.2.0`) |
| `OTEL_ENABLED` | Active l'observabilité distribuée | `false` en local |
| `USE_GOOGLE_VERTEX` | Utiliser Vertex AI au lieu de l'API Gemini | `false` (Gemini API suffit) |
| `DIGITIA_DOMAIN` | Domaine public (Traefik uniquement) | `localhost` (ignoré en local) |

> ⚠️ **pgAdmin** : mettre le **même** mot de passe PostgreSQL dans
> `pgadmin-config/pgpass/pgpass` pour la connexion automatique :
> ```
> postgres:5432:explor:postgres:VOTRE_MOT_DE_PASSE_POSTGRES
> ```

> 🔐 **Vertex AI (optionnel)** : si `USE_GOOGLE_VERTEX=true`, placer la clé de
> compte de service à côté du compose et pointer `GOOGLE_VERTEX_KEY_PATH` dessus
> (ex. `./google_vertex_key_local.json`). Sinon, laisser `false` : seule la clé
> Gemini est requise.

---

## 5. Déploiement local (sans Traefik)

Cible : poste de développement ou déploiement interne, **sans domaine ni HTTPS**.
L'override `docker-compose.local.yml` :
- expose le **frontend sur `localhost:3000`** (pas de Traefik),
- **désactive l'observabilité** (`OTEL_ENABLED=false`, services `obs-*` à 0 replica).

```bash
# 1. Cloner le dépôt
git clone https://github.com/digitia-org/digitia-deploy.git
cd digitia-deploy

# 2. S'authentifier sur GHCR (cf. §3)
echo "VOTRE_TOKEN" | docker login ghcr.io -u UTILISATEUR_FOURNI --password-stdin

# 3. Configurer l'environnement (cf. §4)
cp .env.example .env
#   → éditer .env : mots de passe, GEMINI_API_KEY, et OTEL_ENABLED=false
#   → éditer pgadmin-config/pgpass/pgpass avec le mot de passe Postgres

# 4. Tirer les images
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml pull

# 5. Démarrer la stack
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml up -d
```

Au premier démarrage, `digitia-server` exécute automatiquement les migrations de
base puis les seeds (admin, agents, templates) avant de démarrer l'API — comptez
quelques minutes.

> 💡 Pour éviter de répéter les `-f`, vous pouvez exporter :
> ```bash
> export COMPOSE_FILE=docker-compose.yml:docker-compose.infra.yml:docker-compose.local.yml
> docker compose up -d        # équivaut à la commande complète
> ```

---

## 6. Déploiement serveur (avec Traefik + HTTPS)

Cible : serveur exposé sur Internet, derrière **Traefik** (TLS Let's Encrypt ou
Cloudflare). Géré par la CI/CD (`deploy-manifest.yml`), mais reproductible à la main.

Prérequis : un **stack Traefik séparé** doit tourner et avoir créé le réseau
externe `traefik_network` (projet `-p traefik`, hors de ce dépôt).

```bash
# .env : renseigner DIGITIA_DOMAIN, DIGITIA_PGADMIN_DOMAIN, TRAEFIK_TLS_*, ...

docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.label-traefik.yml pull
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.label-traefik.yml up -d --remove-orphans
```

Réglage TLS (voir commentaires dans `.env.example`) :
- `TRAEFIK_TLS_MAIN=true` → DNS direct, Traefik gère Let's Encrypt.
- `TRAEFIK_TLS_MAIN=false` → domaine derrière le proxy Cloudflare (évite la boucle 308).

> Le déploiement serveur est automatisé : voir `deploy-manifest.yml` et les
> workflows `deploy-{dev,demo,prod}.yml` dans le dépôt `digitia`.

---

## 7. Vérification et accès

```bash
# État des conteneurs (adapter les -f à votre cible)
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml ps
```

Tous les services doivent être `Up` / `healthy`. Accès en **local** :

| Service | URL | Notes |
|---|---|---|
| Frontend Digitia | http://localhost:3000 | Application principale |
| API Server | http://localhost:3001/api/health | Doit répondre `ok` |
| Agent IA | http://localhost:8000/health | Health check FastAPI |
| pgAdmin | http://localhost:5050 | Login = `ADMIN_LOGIN` / `ADMIN_PASSWORD` |
| Neo4j Browser | http://localhost:7474 | `neo4j` / `NEO4J_PASSWORD` |
| MinIO Console | http://localhost:9001 | `MINIO_ACCESS_KEY` / `MINIO_SECRET_KEY` |

Connexion à l'application : `ADMIN_LOGIN` / `ADMIN_PASSWORD` (compte créé au 1er démarrage).

---

## 8. Exploitation au quotidien

Toutes les commandes ci-dessous supposent la cible **locale** ; pour le serveur,
remplacer `docker-compose.local.yml` par `docker-compose.label-traefik.yml`.

```bash
# Logs d'un service
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml logs -f --tail=100 digitia-server

# Redémarrer un service
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml restart digitia-server

# Mettre à jour vers la dernière image
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml pull
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml up -d

# Tout arrêter (conserve les volumes/données)
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml down

# Tout arrêter ET supprimer les données (⚠️ destructif)
docker compose -f docker-compose.yml -f docker-compose.infra.yml -f docker-compose.local.yml down -v
```

> Procédures avancées (reset des données RAG, re-seed admin, accès psql/cypher) :
> voir **`runbook-digitia.md`**.

### 8.1 Alias serveur (raccourcis)

Pour éviter de retaper les longues commandes `docker compose -f … -f … -f …`, le
dépôt fournit un jeu d'alias/fonctions (`digitia-aliases.sh`). Installation
**système, pour tous les utilisateurs** (idempotent, à réexécuter après mise à jour) :

```bash
cd ~/workspace/digitia-org/digitia-deploy
./scripts/install-aliases.sh          # pose /etc/profile.d/digitia-aliases.sh
source /etc/profile.d/digitia-aliases.sh   # ou rouvrir une session SSH
```

Principaux raccourcis (suffixes : `d` = stack complète, `a` = apps, `i` = infra) :

| Alias / fonction | Action |
|---|---|
| `dcud` / `dcdd` | `up -d` / `down` de toute la stack |
| `dcuda` / `dcudi` | `up -d` apps seules / infra seule |
| `dcpsd` / `dcld` | `ps` / `logs -f` de la stack |
| `digitia-restart-all` | `down` + `up -d` complet (recommandé après déploiement) |
| `digitia-restart-app` / `-infra` | redémarre apps / infra sans toucher l'autre |

---

## 9. Dépannage

| Symptôme | Cause probable | Solution |
|---|---|---|
| `network traefik_network declared as external, but could not be found` | Lancement avec `label-traefik` sans que la stack Traefik globale ne soit démarrée | S'assurer que le projet Traefik principal (hors de ce dépôt) tourne et a créé `traefik_network` |
| `unauthorized` / `403` au pull | Non authentifié sur GHCR | Refaire `docker login ghcr.io` (cf. §3) |
| Frontend introuvable sur `:8080` | Le port local est `3000` (override), `8080` est interne | Ouvrir http://localhost:3000 |
| `digitia-server` redémarre en boucle | Postgres pas prêt ou `DATABASE_URL` invalide | `... logs digitia-postgres` puis `... logs digitia-server` |
| Erreur OTel / collecteur au démarrage | `OTEL_ENABLED=true` en local | Mettre `OTEL_ENABLED=false` dans `.env` |
| pgAdmin ne se connecte pas | `pgpass` non synchronisé avec `.env` | Aligner `pgadmin-config/pgpass/pgpass` (cf. §4) |
| `ERR_TOO_MANY_REDIRECTS` (serveur) | Cloudflare proxy + `TRAEFIK_TLS_MAIN=true` | Mettre `TRAEFIK_TLS_MAIN=false`, recréer le conteneur |

---

## 10. Bonnes pratiques

- **Toujours superposer un override** (`local` ou `label-traefik`) ; jamais la base seule.
- **Ne jamais committer `.env`** ni les clés (`google_vertex_key_*.json`) : ils sont git-ignorés.
- **Ne jamais éditer de fichiers directement sur un serveur** (divergence Git) — passer par le dépôt + redéploiement.
- **Versionner les déploiements** via `DIGITIA_VERSION` (éviter `develop` en production).
- **Sauvegarder les volumes** `postgres_data`, `neo4j_data`, `minio_data` avant toute opération destructive.
- **Mots de passe forts** pour Postgres / Neo4j / admin ; ne pas réutiliser les exemples.
- Après mise à jour des images, vérifier les **health checks** (§7) avant de considérer le déploiement réussi.

---

## 11. Support

Contact : support@digitia.ca

Pour : renouvellement du token GHCR, montée de version, incident technique.
