# Journal des déploiements Digitia

Journal append-only — ne jamais modifier une ligne passée, seulement en ajouter.

| Date | Heure | Client/Env | Config (.env) | Version (DIGITIA_VERSION) | Opérateur | Health check | Notes |
|------|-------|-----------|--------------|--------------------------|-----------|--------------|-------|
| 2026-06-14 | — | UMEF | secrets/.env.umef | v0.1.0 | soungsid | à renseigner au déploiement | Config préparée — déploiement à planifier |
